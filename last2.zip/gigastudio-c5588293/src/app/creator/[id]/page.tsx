"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Lock, CreditCard, X, Check } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import VideoCard, { Video } from "@/components/video-card";
import Header from "@/components/header";
import Footer from "@/components/footer";

const creatorMap: Record<string, { name: string; avatar: string }> = {
  "1": { name: "travel_mike", avatar: "https://i.pravatar.cc/150?u=1" },
  "2": { name: "dance_queen", avatar: "https://i.pravatar.cc/150?u=2" },
  "3": { name: "chef_gordon", avatar: "https://i.pravatar.cc/150?u=3" },
  "4": { name: "fit_life", avatar: "https://i.pravatar.cc/150?u=4" },
  "5": { name: "urban_explorer", avatar: "https://i.pravatar.cc/150?u=5" },
  "6": { name: "studio_official", avatar: "https://i.pravatar.cc/150?u=6" },
};

const allVideos: Video[] = [
  { id: "1", title: "Summer Vibes 2024", author: "travel_mike", thumbnail: "https://picsum.photos/seed/v1/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "2", title: "Exclusive Dance Tutorial", author: "dance_queen", thumbnail: "https://picsum.photos/seed/v2/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "3", title: "Cooking Masterclass: Pasta", author: "chef_gordon", thumbnail: "https://picsum.photos/seed/v3/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "4", title: "Secret Workout Plan 💪", author: "fit_life", thumbnail: "https://picsum.photos/seed/v4/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "5", title: "City Night Walk", author: "urban_explorer", thumbnail: "https://picsum.photos/seed/v5/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "6", title: "Behind The Scenes 🤫", author: "studio_official", thumbnail: "https://picsum.photos/seed/v6/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
];

export default function CreatorPage() {
  const params = useParams();
  const router = useRouter();
  const creatorId = params.id as string;
  const creatorInfo = creatorMap[creatorId];
  const creatorVideos = allVideos.filter(v => v.author === creatorInfo?.name);

  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [isVipUnlocked, setIsVipUnlocked] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const handleCardClick = (video: Video) => setSelectedVideo(video);
  const handleCloseModal = () => { setSelectedVideo(null); setPaymentSuccess(false); setPromoCode(""); };
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim()) {
      setPaymentSuccess(true);
      setTimeout(() => {
        setIsVipUnlocked(true);
        handleCloseModal();
      }, 1500);
    }
  };

  if (!creatorInfo) return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <h1 className="text-2xl font-bold">Creator not found</h1>
      <Button onClick={() => router.push("/")} className="mt-4">Go Home</Button>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 container py-8">
        <Button variant="ghost" onClick={() => router.back()} className="mb-6 gap-2 pl-0"><ArrowLeft className="h-4 w-4" /> Back</Button>
        <div className="flex items-end gap-6 mb-10 pb-6 border-b">
          <div className="h-32 w-32 rounded-full p-1 bg-gradient-to-tr from-pink-500 to-violet-500">
            <img src={creatorInfo.avatar} alt={creatorInfo.name} className="h-full w-full rounded-full object-cover border-4 border-background" />
          </div>
          <div className="flex-1 pb-2">
            <h1 className="text-4xl font-bold mb-1">@{creatorInfo.name}</h1>
            <p className="text-muted-foreground">Content Creator • {creatorVideos.length} Videos</p>
          </div>
          <div className="pb-4"><Button size="lg" className="rounded-full px-8">Follow</Button></div>
        </div>
        {creatorVideos.length > 0 ? (
          <div>
            <h2 className="text-2xl font-bold mb-6">Videos</h2>
            {/* Updated Grid: 3 columns for mobile devices */}
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {creatorVideos.map((video) => (
                <VideoCard key={video.id} video={video} onClick={handleCardClick} />
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-20 text-muted-foreground">No videos available for this creator yet.</div>
        )}
      </main>
      <Footer />
      {selectedVideo && (
        <Dialog open={!!selectedVideo} onOpenChange={handleCloseModal}>
          <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-black border-white/10">
            <button onClick={handleCloseModal} className="absolute top-4 right-4 z-10 rounded-full bg-black/50 p-2 text-white hover:bg-black/70 transition-colors"><X size={20} /></button>
            {selectedVideo.isVip && !isVipUnlocked ? (
              <div className="flex flex-col items-center justify-center p-8 text-center space-y-6 bg-background h-[500px]">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10"><Lock className="h-8 w-8 text-primary" /></div>
                <div>
                  <h2 className="text-2xl font-bold">Unlock Premium Content</h2>
                  <p className="text-muted-foreground mt-2">This video is exclusive for VIP members.</p>
                </div>
                {paymentSuccess ? (
                  <div className="flex flex-col items-center text-green-600"><Check size={48} className="mb-2" /><p className="font-medium">Access Granted!</p></div>
                ) : (
                  <form onSubmit={handlePaymentSubmit} className="w-full max-w-sm space-y-4">
                    <Input type="text" placeholder="Enter promo code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} className="text-center" />
                    <Button type="submit" className="w-full" size="lg"><CreditCard className="mr-2 h-4 w-4" />Unlock Now</Button>
                  </form>
                )}
              </div>
            ) : (
              <div className="relative bg-black aspect-[9/16] w-full">
                <video key={selectedVideo.id} autoPlay controls className="h-full w-full object-contain" poster={selectedVideo.thumbnail}>
                  <source src={selectedVideo.videoUrl} type="video/mp4" />
                </video>
              </div>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}