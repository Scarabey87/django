// Client-side mock database simulation
// In a real app, this would be an API communicating with PostgreSQL/MySQL

export interface User {
  id: string;
  name: string;
  email: string;
  password: string; // In real app, this should be hashed!
  role: "user" | "admin" | "vip";
  avatar: string;
}

const USERS_STORAGE_KEY = "live_ai_users";
const SESSION_STORAGE_KEY = "live_ai_session";

// Seed initial data if empty
const seedUsers = () => {
  if (typeof window === "undefined") return [];
  const existing = localStorage.getItem(USERS_STORAGE_KEY);
  if (!existing) {
    const initialUsers: User[] = [
      { id: "u1", name: "Alice Smith", email: "alice@example.com", password: "password123", role: "user", avatar: "https://i.pravatar.cc/150?u=a" },
      { id: "u2", name: "Bob Johnson", email: "bob@example.com", password: "password123", role: "vip", avatar: "https://i.pravatar.cc/150?u=b" },
      { id: "u3", name: "Charlie Admin", email: "admin@liveai.art", password: "admin", role: "admin", avatar: "https://i.pravatar.cc/150?u=c" },
    ];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initialUsers));
    return initialUsers;
  }
  return JSON.parse(existing);
};

export const db = {
  getUsers: (): User[] => {
    return seedUsers();
  },

  addUser: (user: User): boolean => {
    const users = db.getUsers();
    if (users.find(u => u.email === user.email)) return false; // Email exists
    users.push(user);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    return true;
  },

  updateUserRole: (userId: string, newRole: User["role"]): void => {
    const users = db.getUsers();
    const updated = users.map(u => u.id === userId ? { ...u, role: newRole } : u);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updated));
  },

  login: (email: string, password: string): User | null => {
    const users = db.getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    return user || null;
  },

  setSession: (user: User) => {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
  },

  getSession: (): User | null => {
    if (typeof window === "undefined") return null;
    const session = localStorage.getItem(SESSION_STORAGE_KEY);
    return session ? JSON.parse(session) : null;
  },

  clearSession: () => {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  }
};