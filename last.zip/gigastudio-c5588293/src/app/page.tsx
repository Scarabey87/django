"use client";

import { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Lock, CreditCard, X, Check, ArrowUpDown, Clock, Crown } from "lucide-react";
import VideoCard, { Video } from "@/components/video-card";
import CreatorCard, { Creator } from "@/components/creator-card";
import Header from "@/components/header";
import Footer from "@/components/footer";

// Mock Data - Videos
const mockVideos: Video[] = [
  { id: "1", title: "Summer Vibes 2024", author: "travel_mike", thumbnail: "https://picsum.photos/seed/v1/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "2", title: "Exclusive Dance Tutorial", author: "dance_queen", thumbnail: "https://picsum.photos/seed/v2/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "3", title: "Cooking Masterclass: Pasta", author: "chef_gordon", thumbnail: "https://picsum.photos/seed/v3/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "4", title: "Secret Workout Plan 💪", author: "fit_life", thumbnail: "https://picsum.photos/seed/v4/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "5", title: "City Night Walk", author: "urban_explorer", thumbnail: "https://picsum.photos/seed/v5/300/533", isVip: false, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "6", title: "Behind The Scenes 🤫", author: "studio_official", thumbnail: "https://picsum.photos/seed/v6/300/533", isVip: true, videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
];

// Mock Data - Creators
const mockCreators: Creator[] = [
  { id: "1", name: "travel_mike", avatar: "https://i.pravatar.cc/150?u=1", views: 12500, likes: 3400, isLiked: false },
  { id: "2", name: "dance_queen", avatar: "https://i.pravatar.cc/150?u=2", views: 45200, likes: 12000, isLiked: true },
  { id: "3", name: "chef_gordon", avatar: "https://i.pravatar.cc/150?u=3", views: 8900, likes: 500, isLiked: false },
  { id: "4", name: "fit_life", avatar: "https://i.pravatar.cc/150?u=4", views: 22100, likes: 8900, isLiked: false },
  { id: "5", name: "urban_explorer", avatar: "https://i.pravatar.cc/150?u=5", views: 15400, likes: 4200, isLiked: false },
  { id: "6", name: "studio_official", avatar: "https://i.pravatar.cc/150?u=6", views: 100000, likes: 45000, isLiked: true },
];

type SortOption = "date" | "name" | "likes";

export default function Home() {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [isVipUnlocked, setIsVipUnlocked] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [creators, setCreators] = useState<Creator[]>(mockCreators);
  const [sortBy, setSortBy] = useState<SortOption>("likes");
  
  // Timer State
  const [accessExpiry, setAccessExpiry] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>("");

  useEffect(() => {
    const savedExpiry = localStorage.getItem("vipAccessExpiry");
    if (savedExpiry) {
      const expiryDate = parseInt(savedExpiry, 10);
      if (Date.now() < expiryDate) {
        setAccessExpiry(expiryDate);
        setIsVipUnlocked(true);
      } else {
        localStorage.removeItem("vipAccessExpiry");
      }
    }
  }, []);

  useEffect(() => {
    if (!accessExpiry) return;
    const calculateTimeLeft = () => {
      const now = Date.now();
      const difference = accessExpiry - now;
      if (difference <= 0) {
        localStorage.removeItem("vipAccessExpiry");
        setIsVipUnlocked(false);
        setAccessExpiry(null);
        setTimeLeft("");
        window.location.reload();
        return;
      }
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    };
    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [accessExpiry]);

  const handleCardClick = (video: Video) => setSelectedVideo(video);
  const handleCreatorClick = (creator: Creator) => { window.location.href = `/creator/${creator.id}`; };
  const handleLike = (id: string) => {
    setCreators(prev => prev.map(c => {
      if (c.id === id) return { ...c, isLiked: !c.isLiked, likes: c.isLiked ? c.likes - 1 : c.likes + 1 };
      return c;
    }));
  };

  const handleCloseModal = () => { setSelectedVideo(null); setPaymentSuccess(false); setPromoCode(""); };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim()) {
      setPaymentSuccess(true);
      // Default 1 day for demo
      const durationMs = 1 * 24 * 60 * 60 * 1000; 
      const expiry = Date.now() + durationMs;
      setTimeout(() => {
        localStorage.setItem("vipAccessExpiry", expiry.toString());
        setAccessExpiry(expiry);
        setIsVipUnlocked(true);
        handleCloseModal();
      }, 1500);
    }
  };

  const sortedCreators = useMemo(() => {
    const sorted = [...creators];
    switch (sortBy) {
      case "date": return sorted.reverse();
      case "name": return sorted.sort((a, b) => a.name.localeCompare(b.name));
      case "likes": return sorted.sort((a, b) => b.likes - a.likes);
      default: return sorted;
    }
  }, [creators, sortBy]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      {isVipUnlocked && timeLeft && (
        <div className="bg-primary text-primary-foreground py-2 px-4 text-center text-sm font-medium flex items-center justify-center gap-2 sticky top-[57px] z-30">
          <Crown className="h-4 w-4" />
          <span>VIP Access Active: Time remaining </span>
          <span className="bg-primary-foreground/20 px-2 py-0.5 rounded text-white flex items-center gap-1">
             <Clock className="h-3 w-3" /> {timeLeft}
          </span>
        </div>
      )}
      
      <main className="flex-1 container py-8 space-y-12">
        <section>
          <div className="mb-8">
            <h1 className="text-4xl font-bold tracking-tight mb-2">Trending Now</h1>
            <p className="text-muted-foreground">Discover the best video content from our creators</p>
          </div>
          {/* Updated Grid: 3 columns for mobile devices */}
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {mockVideos.map((video) => (
              <VideoCard key={video.id} video={video} onClick={handleCardClick} />
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold tracking-tight">Popular Creators</h2>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                <SelectTrigger className="w-[140px]"><SelectValue placeholder="Sort by" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="likes">Most Liked</SelectItem>
                  <SelectItem value="name">Name A-Z</SelectItem>
                  <SelectItem value="date">Newest</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          {/* Updated Grid: 3 columns for mobile devices */}
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {sortedCreators.map((creator) => (
              <CreatorCard key={creator.id} creator={creator} onClick={handleCreatorClick} onLike={handleLike} />
            ))}
          </div>
        </section>
      </main>

      <Footer />

      {selectedVideo && (
        <Dialog open={!!selectedVideo} onOpenChange={handleCloseModal}>
          <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-black border-white/10">
            <button onClick={handleCloseModal} className="absolute top-4 right-4 z-10 rounded-full bg-black/50 p-2 text-white hover:bg-black/70 transition-colors">
              <X size={20} />
            </button>
            {selectedVideo.isVip && !isVipUnlocked ? (
              <div className="flex flex-col items-center justify-center p-8 text-center space-y-6 bg-background h-[500px]">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10"><Lock className="h-8 w-8 text-primary" /></div>
                <div>
                  <h2 className="text-2xl font-bold">Unlock Premium Content</h2>
                  <p className="text-muted-foreground mt-2">This video is exclusive for VIP members. Subscribe or enter a promo code to watch.</p>
                </div>
                {paymentSuccess ? (
                  <div className="flex flex-col items-center text-green-600 animate-in fade-in zoom-in duration-300">
                    <Check size={48} className="mb-2" /><p className="font-medium">Access Granted!</p>
                  </div>
                ) : (
                  <form onSubmit={handlePaymentSubmit} className="w-full max-w-sm space-y-4">
                    <div className="space-y-2">
                      <Input type="text" placeholder="Enter promo code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} className="text-center" />
                    </div>
                    <Button type="submit" className="w-full" size="lg"><CreditCard className="mr-2 h-4 w-4" />Unlock Now</Button>
                    <p className="text-xs text-muted-foreground">Need help? Contact us at <span className="text-primary">Infijium@gmail.com</span></p>
                  </form>
                )}
              </div>
            ) : (
              <div className="relative bg-black aspect-[9/16] w-full">
                <video key={selectedVideo.id} autoPlay controls className="h-full w-full object-contain" poster={selectedVideo.thumbnail}>
                  <source src={selectedVideo.videoUrl} type="video/mp4" />
                </video>
              </div>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}